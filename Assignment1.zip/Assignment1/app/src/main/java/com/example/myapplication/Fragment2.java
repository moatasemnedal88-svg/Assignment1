package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.databinding.Fragment2Binding;

/**
 * Fragment2 - Collects basic user info: name, email, gender, university.
 * Communicates with the Host Activity via the OnFragment2Listener interface,
 * passing the collected name when Continue is tapped.
 */
public class Fragment2 extends Fragment {

    private Fragment2Binding binding;

    // Argument key used when creating via newInstance(name)
    private static final String ARG_NAME = "arg_name";

    // ─── Interface ────────────────────────────────────────────────────────────
    public interface OnFragment2Listener {
        /**
         * Called when the user fills in their details and taps Continue.
         *
         * @param name The full name entered by the user.
         */
        void onFragment2Continue(String name);
    }

    private OnFragment2Listener listener;

    // ─── Factory ──────────────────────────────────────────────────────────────
    public Fragment2() {
        // Required empty public constructor
    }

    /**
     * Creates a new Fragment2 instance.
     * The name parameter is not pre-filled in the starter, but the factory
     * pattern is kept for extensibility.
     */
    public static Fragment2 newInstance() {
        return new Fragment2();
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnFragment2Listener) {
            listener = (OnFragment2Listener) context;
        } else {
            throw new RuntimeException(context + " must implement OnFragment2Listener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = Fragment2Binding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.buttonContinue.setOnClickListener(v -> {
            String name  = binding.editTextName.getText() != null
                    ? binding.editTextName.getText().toString().trim()
                    : "";
            String email = binding.editTextEmail.getText() != null
                    ? binding.editTextEmail.getText().toString().trim()
                    : "";

            // Validate required fields
            if (TextUtils.isEmpty(name)) {
                binding.layoutName.setError("Please enter your name");
                return;
            }
            binding.layoutName.setError(null);

            if (TextUtils.isEmpty(email)) {
                binding.layoutEmail.setError("Please enter your email");
                return;
            }
            binding.layoutEmail.setError(null);

            // Send name (and any other data) to the Host Activity via interface
            if (listener != null) {
                listener.onFragment2Continue(name);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.databinding.Fragment3Binding;

/**
 * Fragment3 - Final confirmation screen.
 * Displays the user's name received from the Host Activity.
 * Contains a CheckBox; when checked the Continue button becomes enabled
 * and its text changes to "Finish".
 * Checkbox state changes are reported to the Host Activity via the
 * OnFragment3Listener interface.
 */
public class Fragment3 extends Fragment {

    private Fragment3Binding binding;

    // Bundle key for receiving the user's name
    private static final String ARG_NAME = "user_name";

    // ─── Interface ────────────────────────────────────────────────────────────
    public interface OnFragment3Listener {
        /**
         * Called whenever the confirmation checkbox state changes.
         *
         * @param isChecked true when checked, false when unchecked.
         */
        void onCheckboxStateChanged(boolean isChecked);
    }

    private OnFragment3Listener listener;

    // ─── Factory ──────────────────────────────────────────────────────────────
    public Fragment3() {
        // Required empty public constructor
    }

    /**
     * Creates a new Fragment3 instance with the user's name passed as an argument.
     *
     * @param name The name to display in this fragment.
     * @return A new instance of Fragment3.
     */
    public static Fragment3 newInstance(String name) {
        Fragment3 fragment = new Fragment3();
        Bundle args = new Bundle();
        args.putString(ARG_NAME, name);
        fragment.setArguments(args);
        return fragment;
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnFragment3Listener) {
            listener = (OnFragment3Listener) context;
        } else {
            throw new RuntimeException(context + " must implement OnFragment3Listener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = Fragment3Binding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // ── Retrieve and display the name passed via Bundle ──────────────────
        String userName = "";
        if (getArguments() != null) {
            userName = getArguments().getString(ARG_NAME, "");
        }
        binding.textWelcomeName.setText("Welcome, " + userName + "!");

        // ── Ensure button starts disabled ────────────────────────────────────
        binding.buttonFinish.setEnabled(false);
        binding.buttonFinish.setText("Continue");

        // ── CheckBox listener (uses interface for communication) ─────────────
        binding.checkboxAgree.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Enable button and change text to "Finish"
                binding.buttonFinish.setEnabled(true);
                binding.buttonFinish.setText("Finish");
                binding.buttonFinish.setBackgroundTintList(
                        requireContext().getColorStateList(R.color.purple_500));
            } else {
                // Disable button and revert text to "Continue"
                binding.buttonFinish.setEnabled(false);
                binding.buttonFinish.setText("Continue");
                binding.buttonFinish.setBackgroundTintList(
                        requireContext().getColorStateList(R.color.button_disabled));
            }

            // Notify Host Activity via interface
            if (listener != null) {
                listener.onCheckboxStateChanged(isChecked);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

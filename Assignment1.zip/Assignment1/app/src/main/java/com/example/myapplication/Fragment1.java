package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.databinding.Fragment1Binding;

/**
 * Fragment1 - Welcome / splash screen shown at app startup.
 * Communicates with the Host Activity via the OnFragment1Listener interface.
 */
public class Fragment1 extends Fragment {

    private Fragment1Binding binding;

    // ─── Interface ────────────────────────────────────────────────────────────
    public interface OnFragment1Listener {
        void onFragment1Continue();
    }

    private OnFragment1Listener listener;

    // ─── Lifecycle ────────────────────────────────────────────────────────────
    public Fragment1() {
        // Required empty public constructor
    }

    public static Fragment1 newInstance() {
        return new Fragment1();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnFragment1Listener) {
            listener = (OnFragment1Listener) context;
        } else {
            throw new RuntimeException(context + " must implement OnFragment1Listener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = Fragment1Binding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // When user taps "Get Started", notify the Host Activity
        binding.buttonContinue.setOnClickListener(v -> {
            if (listener != null) {
                listener.onFragment1Continue();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

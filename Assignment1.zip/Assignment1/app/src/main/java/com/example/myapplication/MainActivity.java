package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityMainBinding;

/**
 * MainActivity - Host Activity.
 *
 * Implements all Fragment listener interfaces so it can:
 *  1. Switch from Fragment1 → Fragment2 when the user taps "Get Started".
 *  2. Receive the user's name from Fragment2 and switch to Fragment3.
 *  3. Receive checkbox state updates from Fragment3.
 */
public class MainActivity extends AppCompatActivity
        implements Fragment1.OnFragment1Listener,
                   Fragment2.OnFragment2Listener,
                   Fragment3.OnFragment3Listener {

    private ActivityMainBinding binding;

    // Stores the user's name collected in Fragment2
    private String userName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Load Fragment1 as the initial screen
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.fragment_container, Fragment1.newInstance())
                    .commit();
        }
    }

    // ─── Fragment1.OnFragment1Listener ────────────────────────────────────────
    @Override
    public void onFragment1Continue() {
        // Navigate to Fragment2
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, Fragment2.newInstance())
                .addToBackStack(null)
                .commit();
    }

    // ─── Fragment2.OnFragment2Listener ────────────────────────────────────────
    @Override
    public void onFragment2Continue(String name) {
        // Store the name received from Fragment2
        userName = name;

        // Navigate to Fragment3, passing the name via Bundle (setArguments)
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, Fragment3.newInstance(userName))
                .addToBackStack(null)
                .commit();
    }

    // ─── Fragment3.OnFragment3Listener ────────────────────────────────────────
    @Override
    public void onCheckboxStateChanged(boolean isChecked) {
        // Host Activity is aware of checkbox state.
        // (No extra action required beyond what Fragment3 already handles in the UI)
        if (isChecked) {
            Toast.makeText(this, "Agreement confirmed ✓", Toast.LENGTH_SHORT).show();
        }
    }
}
